var app = angular.module('DonationWebApp', ['ngRoute']);

app.factory('donations', function(){

  var donations = [{paymenttype: 'PayPal', amount: 1500, upvotes: 0},
                    {paymenttype: 'Direct', amount: 1000, upvotes: 2}
                    ];

donations.add = function(paymenttype, amount){
    donations.push({paymenttype: paymenttype, amount: amount, upvotes: 0});
  };

donations.deleteDonation = function(donation) {
    var index = donations.indexOf(donation);
    donations.splice(index, 1);  
  };

  donations.incrementUpvotes = function(donation) {
     donation.upvotes += 1;
  };

  return donations;
});

app.config(function($routeProvider) {
        $routeProvider

            // route for the home page
            .when('/', {
                templateUrl : 'pages/home.ejs',
                controller  : 'mainController'
            })

             // route for the donate page
            .when('/donate', {
                templateUrl : 'pages/donate.ejs',
                controller  : 'donateController'
            })

             // route for the donations page
            .when('/donations', {
                templateUrl : 'pages/donations.ejs',
                controller  : 'donationsController'
            })

            // route for the about page
            .when('/about', {
                templateUrl : 'pages/about.ejs',
                controller  : 'aboutController'
            })

            // route for the contact page
            .when('/contact', {
                templateUrl : 'pages/contact.ejs',
                controller  : 'contactController'
            });
    });


  
  


